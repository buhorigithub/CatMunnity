import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { Helmet, HelmetProvider } from 'react-helmet-async';

createRoot(document.getElementById("root")!).render(
  <HelmetProvider>
    <Helmet>
      <title>Catmunitty - Bersama Peduli Makhluk Jalanan</title>
      <meta name="description" content="Platform patungan untuk pangan kucing terlantar. Bersama kita buat perbedaan untuk makhluk jalanan." />
      <meta property="og:title" content="Catmunitty - Bersama Peduli Makhluk Jalanan" />
      <meta property="og:description" content="Platform patungan untuk pangan kucing terlantar. Bersama kita buat perbedaan untuk makhluk jalanan." />
      <meta property="og:type" content="website" />
      <meta property="og:url" content="https://catmunitty.org" />
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
    </Helmet>
    <App />
  </HelmetProvider>
);
