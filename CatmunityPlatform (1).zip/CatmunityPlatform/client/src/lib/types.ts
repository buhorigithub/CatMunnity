// Campaign Types
export interface Campaign {
  id: number;
  title: string;
  description: string;
  location: string;
  image: string;
  isUrgent: boolean;
  daysLeft: number;
  targetAmount: number;
  currentAmount: number;
  donorCount: number;
  createdAt: string;
}

// Donation Types
export interface Donation {
  id: number;
  campaignId?: number;
  fullName: string;
  email: string;
  amount: number;
  paymentMethod: 'transfer' | 'ewallet' | 'credit';
  message?: string;
  createdAt: string;
}

// Volunteer Types
export interface Volunteer {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  location: string;
  role: string;
  experience?: string;
  availability: string;
  createdAt: string;
}

// Contact Types
export interface ContactMessage {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
}

// Testimonial Types
export interface Testimonial {
  id: number;
  name: string;
  role: string;
  image: string;
  quote: string;
}

// Impact Statistics
export interface ImpactStats {
  cats: number;
  locations: number;
  volunteers: number;
}

// Success Story
export interface SuccessStory {
  id: number;
  title: string;
  description: string;
  image: string;
  fullStory?: string;
}

// Financial Report
export interface FinancialReport {
  id: number;
  period: string;
  totalDonations: number;
  expenses: ExpenseItem[];
}

export interface ExpenseItem {
  category: string;
  amount: number;
  percentage: number;
}
