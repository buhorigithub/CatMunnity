import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface FaqItemProps {
  question: string;
  answer: string;
}

export default function FaqItem({ question, answer }: FaqItemProps) {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <div 
        className="px-6 py-4 cursor-pointer flex justify-between items-center"
        onClick={() => setIsOpen(!isOpen)}
      >
        <h3 className="font-heading font-bold text-lg text-dark">{question}</h3>
        {isOpen ? (
          <ChevronUp className="text-xl text-primary" />
        ) : (
          <ChevronDown className="text-xl text-primary" />
        )}
      </div>
      {isOpen && (
        <div className="px-6 py-4 bg-primary/5 border-t border-gray-100">
          <p className="text-dark/80 text-sm">{answer}</p>
        </div>
      )}
    </div>
  );
}
