import { Link } from 'wouter';
import { Footprints, MapPin, Mail, Phone, Send, Instagram, Facebook, Twitter, Youtube } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function Footer() {
  return (
    <footer className="bg-primary text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center mr-2">
                <Footprints className="text-primary h-5 w-5" />
              </div>
              <span className="font-heading font-bold text-2xl">
                Cat<span className="text-white">munitty</span>
              </span>
            </div>
            <p className="text-white/80 mb-4">
              Platform patungan untuk pangan kucing terlantar. Bersama kita buat perbedaan untuk makhluk jalanan.
            </p>
            <div className="flex space-x-4">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-white/80">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-white/80">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-white/80">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-white/80">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-heading font-bold text-lg mb-4">Link Cepat</h3>
            <ul className="space-y-2">
              <li><Link href="/" className="text-white/80 hover:text-white">Beranda</Link></li>
              <li><Link href="/about" className="text-white/80 hover:text-white">Tentang Kami</Link></li>
              <li><Link href="/campaigns" className="text-white/80 hover:text-white">Kampanye</Link></li>
              <li><Link href="/volunteer" className="text-white/80 hover:text-white">Relawan</Link></li>
              <li><Link href="/impact" className="text-white/80 hover:text-white">Dampak</Link></li>
              <li><Link href="/contact" className="text-white/80 hover:text-white">Kontak</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-heading font-bold text-lg mb-4">Kampanye Populer</h3>
            <ul className="space-y-2">
              <li><Link href="/campaigns" className="text-white/80 hover:text-white">Kucing Jalanan Pasar Minggu</Link></li>
              <li><Link href="/campaigns" className="text-white/80 hover:text-white">Kucing Stasiun Bandung</Link></li>
              <li><Link href="/campaigns" className="text-white/80 hover:text-white">Feeding Station Surabaya</Link></li>
              <li><Link href="/campaigns" className="text-white/80 hover:text-white">Induk & Anak Terminal Pulogadung</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-heading font-bold text-lg mb-4">Kontak</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <MapPin className="h-4 w-4 mr-2" />
                <span className="text-white/80">Jl. Kucing Bahagia No. 5, Jakarta Selatan</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-4 w-4 mr-2" />
                <span className="text-white/80">hello@catmunitty.org</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-4 w-4 mr-2" />
                <span className="text-white/80">+62 812 3456 7890</span>
              </li>
            </ul>
            
            <h3 className="font-heading font-bold text-lg mt-6 mb-4">Newsletter</h3>
            <form className="flex">
              <Input 
                type="email" 
                placeholder="Email Anda" 
                className="rounded-l-lg border-0 text-dark focus-visible:ring-0 focus-visible:ring-offset-0" 
              />
              <Button type="submit" className="bg-secondary hover:bg-secondary/90 text-white rounded-r-lg transition duration-300">
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-white/20 mt-8 pt-8 text-center">
          <p className="text-white/80">&copy; {new Date().getFullYear()} Catmunitty. Semua hak dilindungi.</p>
        </div>
      </div>
    </footer>
  );
}
