import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Footprints } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu } from 'lucide-react';

export default function Navbar() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  
  const isActive = (path: string) => {
    return location === path ? 'active-nav' : '';
  };
  
  const navLinks = [
    { name: 'Beranda', path: '/' },
    { name: 'Tentang Kami', path: '/about' },
    { name: 'Kampanye', path: '/campaigns' },
    { name: 'Relawan', path: '/volunteer' },
    { name: 'Dampak', path: '/impact' },
    { name: 'Kontak', path: '/contact' },
  ];

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link href="/" className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center mr-2">
              <Footprints className="text-white h-5 w-5" />
            </div>
            <span className="font-heading font-bold text-2xl text-dark">
              Cat<span className="text-primary">munitty</span>
            </span>
          </Link>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link 
                key={link.path} 
                href={link.path} 
                className={`nav-link font-heading ${isActive(link.path)}`}
              >
                {link.name}
              </Link>
            ))}
          </div>
          
          <Link href="/donate" className="hidden md:inline-block">
            <Button className="bg-primary hover:bg-primary/90 text-white px-6 py-2 rounded-full font-medium transition duration-300">
              Donasi Sekarang
            </Button>
          </Link>
          
          {/* Mobile Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" className="p-0">
                <Menu className="h-6 w-6 text-dark" />
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="pt-10">
              <div className="flex flex-col space-y-4">
                {navLinks.map((link) => (
                  <Link 
                    key={link.path} 
                    href={link.path} 
                    className="block py-2 text-dark hover:text-primary font-heading"
                    onClick={() => setIsOpen(false)}
                  >
                    {link.name}
                  </Link>
                ))}
                <Link href="/donate" onClick={() => setIsOpen(false)}>
                  <Button className="w-full bg-primary text-white px-4 py-2 rounded-full text-center font-medium">
                    Donasi Sekarang
                  </Button>
                </Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
