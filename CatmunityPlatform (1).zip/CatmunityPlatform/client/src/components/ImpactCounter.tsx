import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';

interface ImpactCounterProps {
  value: number;
  label: string;
  delay?: number;
  duration?: number;
}

export default function ImpactCounter({ 
  value, 
  label, 
  delay = 0, 
  duration = 2000 
}: ImpactCounterProps) {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    let start = 0;
    const end = value;
    
    // First set a delay if needed, then start counting
    const timer = setTimeout(() => {
      // if value is too big, don't count every integer
      const step = end > 100 ? Math.floor(end / 100) : 1;
      
      // if no need to count (immediate or very small numbers)
      if (duration <= 0) {
        setCount(end);
        return;
      }
      
      // get the time now
      let startTime = performance.now();
      
      // start counting
      const timer = setInterval(() => {
        const timePassed = performance.now() - startTime;
        if (timePassed > duration) {
          setCount(end);
          clearInterval(timer);
          return;
        }
        
        // calculate the number of steps that have passed based on the time
        const progress = timePassed / duration;
        const currentCount = Math.round(progress * end);
        
        if (currentCount > start) {
          start = currentCount;
          setCount(start);
        }
      }, 16); // roughly 60fps
    }, delay);
    
    return () => {
      clearTimeout(timer);
    };
  }, [value, delay, duration]);
  
  return (
    <Card className="bg-accent rounded-xl p-8 text-center shadow-md">
      <CardContent className="p-0">
        <div className="text-primary text-4xl font-bold font-heading mb-2">
          {count > 999 ? `${count.toLocaleString('id-ID')}+` : count}
        </div>
        <p className="text-dark font-medium">{label}</p>
      </CardContent>
    </Card>
  );
}
