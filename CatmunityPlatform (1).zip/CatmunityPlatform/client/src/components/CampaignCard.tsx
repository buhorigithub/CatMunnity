import { Link } from 'wouter';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Campaign } from '@/lib/types';

interface CampaignCardProps {
  campaign: Campaign;
  featured?: boolean;
}

export default function CampaignCard({ campaign, featured = false }: CampaignCardProps) {
  const { 
    id, 
    title, 
    description, 
    location, 
    image, 
    isUrgent, 
    daysLeft, 
    targetAmount, 
    currentAmount, 
    donorCount 
  } = campaign;
  
  const progressPercentage = Math.round((currentAmount / targetAmount) * 100);
  
  if (featured) {
    return (
      <Card className="bg-white rounded-2xl shadow-lg overflow-hidden max-w-5xl mx-auto">
        <div className="md:flex">
          <div className="md:w-1/2">
            <img 
              src={image} 
              alt={title} 
              className="h-full w-full object-cover" 
            />
          </div>
          <div className="md:w-1/2 p-8">
            <div className="flex items-center mb-4">
              {isUrgent && (
                <Badge variant="outline" className="bg-primary/20 text-primary rounded-full px-4 py-1 text-sm font-medium">
                  Mendesak
                </Badge>
              )}
              <span className="ml-3 text-dark/60 text-sm">{daysLeft} hari tersisa</span>
            </div>
            <h3 className="font-heading font-bold text-2xl mb-4 text-dark">{title}</h3>
            <p className="text-dark/80 mb-6">{description}</p>
            
            <div className="mb-6">
              <div className="flex justify-between text-sm mb-1">
                <span className="font-medium">Terkumpul: Rp {currentAmount.toLocaleString('id-ID')}</span>
                <span className="text-primary font-medium">{progressPercentage}%</span>
              </div>
              <Progress value={progressPercentage} className="h-2.5 bg-gray-200" />
              <div className="flex justify-between text-sm mt-1">
                <span>Target: Rp {targetAmount.toLocaleString('id-ID')}</span>
                <span>{donorCount} donatur</span>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <Link href="/donate">
                <Button className="bg-primary hover:bg-primary/90 text-white font-medium px-6 py-3 rounded-full text-center flex-1 transition duration-300 w-full">
                  Donasi Sekarang
                </Button>
              </Link>
              <Link href={`/campaigns/${id}`}>
                <Button variant="outline" className="border border-primary text-primary hover:bg-primary/5 font-medium px-6 py-3 rounded-full text-center transition duration-300 w-full">
                  Detail Kampanye
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </Card>
    );
  }
  
  return (
    <Card className="bg-white rounded-xl overflow-hidden shadow-md">
      <img 
        src={image} 
        alt={title} 
        className="w-full h-48 object-cover" 
      />
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          {isUrgent ? (
            <Badge variant="outline" className="bg-primary/20 text-primary rounded-full px-3 py-1 text-xs font-medium">
              Mendesak
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-secondary/30 text-secondary rounded-full px-3 py-1 text-xs font-medium">
              {location}
            </Badge>
          )}
          <span className="ml-3 text-dark/60 text-xs">{daysLeft} hari tersisa</span>
        </div>
        <h3 className="font-heading font-bold text-xl mb-3 text-dark">{title}</h3>
        <p className="text-dark/80 text-sm mb-4">{description}</p>
        
        <div className="mb-4">
          <div className="flex justify-between text-xs mb-1">
            <span className="font-medium">Terkumpul: Rp {currentAmount.toLocaleString('id-ID')}</span>
            <span className="text-primary font-medium">{progressPercentage}%</span>
          </div>
          <Progress value={progressPercentage} className="h-2 bg-gray-200" />
          <div className="flex justify-between text-xs mt-1">
            <span>Target: Rp {targetAmount.toLocaleString('id-ID')}</span>
            <span>{donorCount} donatur</span>
          </div>
        </div>
        
        <Link href={`/donate?campaign=${id}`}>
          <Button className="w-full bg-primary hover:bg-primary/90 text-white font-medium px-4 py-2 rounded-full text-center text-sm transition duration-300">
            Dukung Kampanye
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
