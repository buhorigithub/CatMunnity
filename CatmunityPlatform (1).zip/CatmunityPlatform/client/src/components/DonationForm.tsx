import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useMutation } from '@tanstack/react-query';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Campaign } from '@/lib/types';

const donationSchema = z.object({
  fullName: z.string().min(3, 'Nama lengkap minimal 3 karakter'),
  email: z.string().email('Email tidak valid'),
  amount: z.string().refine(val => !isNaN(Number(val)) && Number(val) >= 10000, {
    message: 'Jumlah minimal donasi Rp 10.000',
  }),
  paymentMethod: z.enum(['transfer', 'ewallet', 'credit']),
  message: z.string().optional(),
  campaignId: z.number().optional(),
});

type DonationFormValues = z.infer<typeof donationSchema>;

interface DonationFormProps {
  selectedCampaign?: Campaign;
}

export default function DonationForm({ selectedCampaign }: DonationFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<DonationFormValues>({
    resolver: zodResolver(donationSchema),
    defaultValues: {
      fullName: '',
      email: '',
      amount: '50000',
      paymentMethod: 'transfer',
      message: '',
      campaignId: selectedCampaign?.id,
    },
  });
  
  const donation = useMutation({
    mutationFn: async (values: DonationFormValues) => {
      setIsSubmitting(true);
      const response = await apiRequest('POST', '/api/donations', values);
      const data = await response.json();
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Donasi berhasil!",
        description: "Terima kasih atas dukungan Anda untuk kucing jalanan.",
      });
      form.reset();
      setIsSubmitting(false);
    },
    onError: (error) => {
      toast({
        title: "Donasi gagal",
        description: error.message || "Terjadi kesalahan. Silakan coba lagi.",
        variant: "destructive"
      });
      setIsSubmitting(false);
    }
  });
  
  function onSubmit(values: DonationFormValues) {
    donation.mutate(values);
  }
  
  const predefinedAmounts = [
    { value: '50000', label: 'Rp 50.000' },
    { value: '100000', label: 'Rp 100.000' },
    { value: '250000', label: 'Rp 250.000' },
    { value: '500000', label: 'Rp 500.000' },
  ];

  return (
    <Card className="bg-white rounded-xl shadow-md">
      <CardContent className="p-6 md:p-8">
        <h2 className="font-heading font-bold text-2xl mb-6 text-dark">Formulir Donasi</h2>
        
        {selectedCampaign && (
          <div className="mb-6 p-4 bg-accent rounded-lg">
            <h3 className="font-heading font-medium text-lg mb-2">
              Donasi untuk: {selectedCampaign.title}
            </h3>
            <p className="text-sm text-dark/80">{selectedCampaign.description}</p>
          </div>
        )}
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="fullName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nama Lengkap</FormLabel>
                  <FormControl>
                    <Input placeholder="Masukkan nama lengkap Anda" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input placeholder="Masukkan email Anda" type="email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Jumlah Donasi</FormLabel>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {predefinedAmounts.map((amount) => (
                      <Button
                        key={amount.value}
                        type="button"
                        variant={field.value === amount.value ? "default" : "outline"}
                        className={`rounded-full ${
                          field.value === amount.value ? 'bg-primary text-white' : 'border-primary text-primary'
                        }`}
                        onClick={() => form.setValue('amount', amount.value)}
                      >
                        {amount.label}
                      </Button>
                    ))}
                  </div>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-dark/60">Rp</span>
                      <Input 
                        placeholder="Jumlah donasi lainnya" 
                        className="pl-10" 
                        {...field} 
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="paymentMethod"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Metode Pembayaran</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="transfer" id="transfer" />
                        <FormLabel htmlFor="transfer" className="font-normal cursor-pointer">Transfer Bank</FormLabel>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="ewallet" id="ewallet" />
                        <FormLabel htmlFor="ewallet" className="font-normal cursor-pointer">E-Wallet (OVO, GoPay, DANA)</FormLabel>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="credit" id="credit" />
                        <FormLabel htmlFor="credit" className="font-normal cursor-pointer">Kartu Kredit</FormLabel>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Pesan (opsional)</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Tulis pesan untuk tim Catmunitty atau kucing jalanan" 
                      className="resize-none" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button
              type="submit"
              className="w-full bg-primary hover:bg-primary/90 text-white font-medium px-6 py-3 rounded-full"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Memproses...' : 'Donasi Sekarang'}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
