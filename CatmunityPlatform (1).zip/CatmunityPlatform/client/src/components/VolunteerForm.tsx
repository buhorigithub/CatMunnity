import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useMutation } from '@tanstack/react-query';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage,
  FormDescription 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';

const volunteerSchema = z.object({
  fullName: z.string().min(3, 'Nama lengkap minimal 3 karakter'),
  email: z.string().email('Email tidak valid'),
  phone: z.string().min(10, 'Nomor telepon minimal 10 digit'),
  location: z.string().min(2, 'Silakan masukkan kota domisili Anda'),
  role: z.string().min(1, 'Silakan pilih peran yang diminati'),
  experience: z.string().optional(),
  availability: z.string().min(1, 'Silakan pilih ketersediaan waktu'),
  termsAgreed: z.boolean().refine(val => val === true, {
    message: 'Anda harus menyetujui persyaratan untuk mendaftar',
  }),
});

type VolunteerFormValues = z.infer<typeof volunteerSchema>;

export default function VolunteerForm() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<VolunteerFormValues>({
    resolver: zodResolver(volunteerSchema),
    defaultValues: {
      fullName: '',
      email: '',
      phone: '',
      location: '',
      role: '',
      experience: '',
      availability: '',
      termsAgreed: false,
    },
  });
  
  const volunteer = useMutation({
    mutationFn: async (values: VolunteerFormValues) => {
      setIsSubmitting(true);
      const response = await apiRequest('POST', '/api/volunteers', values);
      const data = await response.json();
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Pendaftaran berhasil!",
        description: "Terima kasih telah mendaftar sebagai relawan. Kami akan menghubungi Anda segera.",
      });
      form.reset();
      setIsSubmitting(false);
    },
    onError: (error) => {
      toast({
        title: "Pendaftaran gagal",
        description: error.message || "Terjadi kesalahan. Silakan coba lagi.",
        variant: "destructive"
      });
      setIsSubmitting(false);
    }
  });
  
  function onSubmit(values: VolunteerFormValues) {
    volunteer.mutate(values);
  }

  return (
    <div id="volunteer-form" className="bg-white rounded-2xl shadow-lg p-8">
      <h2 className="font-heading font-bold text-2xl mb-6 text-dark text-center">Formulir Pendaftaran Relawan</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="fullName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nama Lengkap</FormLabel>
                  <FormControl>
                    <Input placeholder="Masukkan nama lengkap Anda" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input placeholder="Masukkan email Anda" type="email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nomor Telepon</FormLabel>
                  <FormControl>
                    <Input placeholder="Contoh: 08123456789" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Domisili (Kota)</FormLabel>
                  <FormControl>
                    <Input placeholder="Masukkan kota domisili Anda" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="role"
              render={({ field }) => (
                <FormItem className="md:col-span-2">
                  <FormLabel>Peran yang Diminati</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih peran yang Anda minati" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="feeder">Pemberi Makan</SelectItem>
                      <SelectItem value="documentation">Dokumentasi</SelectItem>
                      <SelectItem value="campaign">Kampanye</SelectItem>
                      <SelectItem value="multiple">Bisa melakukan beberapa peran</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="experience"
              render={({ field }) => (
                <FormItem className="md:col-span-2">
                  <FormLabel>Pengalaman dengan Kucing (opsional)</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Ceritakan pengalaman Anda dengan kucing, jika ada" 
                      className="resize-none" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="availability"
              render={({ field }) => (
                <FormItem className="md:col-span-2">
                  <FormLabel>Ketersediaan Waktu</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih ketersediaan waktu Anda" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="weekday-morning">Hari Kerja - Pagi</SelectItem>
                      <SelectItem value="weekday-afternoon">Hari Kerja - Siang/Sore</SelectItem>
                      <SelectItem value="weekend">Akhir Pekan</SelectItem>
                      <SelectItem value="flexible">Fleksibel</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="termsAgreed"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel>
                    Saya bersedia untuk berkomitmen minimal 3 bulan sebagai relawan dan mematuhi kode etik Catmunitty dalam menangani kucing jalanan.
                  </FormLabel>
                  <FormMessage />
                </div>
              </FormItem>
            )}
          />
          
          <Button
            type="submit"
            className="w-full bg-primary hover:bg-primary/90 text-white font-medium px-6 py-3 rounded-full"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Memproses...' : 'Kirim Pendaftaran'}
          </Button>
        </form>
      </Form>
      
      <div className="text-center mt-8">
        <p className="text-dark/80 text-sm">
          Punya pertanyaan tentang relawan? <a href="/contact" className="text-primary hover:underline">Hubungi kami</a>
        </p>
      </div>
    </div>
  );
}
