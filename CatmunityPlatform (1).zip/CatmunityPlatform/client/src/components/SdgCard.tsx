import { LucideIcon } from "lucide-react";

interface SdgCardProps {
  number: number;
  title: string;
  description: string;
  icon: LucideIcon;
  color: string;
}

export default function SdgCard({ number, title, description, icon: Icon, color }: SdgCardProps) {
  return (
    <div className="w-full sm:w-[45%] md:w-[22%] bg-accent rounded-xl p-6 shadow-md transform hover:scale-105 transition duration-300">
      <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center bg-${color} text-white`}>
        <Icon className="h-6 w-6" />
      </div>
      <h3 className="font-heading font-bold text-xl mb-2">SDG {number}</h3>
      <p className="text-dark/80 text-sm">{title} - {description}</p>
    </div>
  );
}
