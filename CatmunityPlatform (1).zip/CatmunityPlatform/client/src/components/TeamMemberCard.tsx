import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';

interface TeamMemberCardProps {
  name: string;
  role: string;
  image: string;
  description: string;
}

export default function TeamMemberCard({ 
  name, 
  role, 
  image, 
  description 
}: TeamMemberCardProps) {
  const initials = name
    .split(' ')
    .map(part => part.charAt(0))
    .join('')
    .toUpperCase();
    
  return (
    <Card className="bg-white p-6 rounded-xl shadow-md text-center">
      <CardContent className="p-0">
        <Avatar className="w-24 h-24 mx-auto mb-4">
          <AvatarImage src={image} alt={`Foto ${name}`} className="object-cover" />
          <AvatarFallback className="bg-primary/20 text-primary">{initials}</AvatarFallback>
        </Avatar>
        <h3 className="font-heading font-bold text-lg mb-1 text-dark">{name}</h3>
        <p className="text-primary font-medium text-sm mb-3">{role}</p>
        <p className="text-dark/80 text-sm">{description}</p>
      </CardContent>
    </Card>
  );
}
