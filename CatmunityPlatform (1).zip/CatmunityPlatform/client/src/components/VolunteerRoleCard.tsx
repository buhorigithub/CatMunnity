import { ReactNode } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LucideIcon } from 'lucide-react';

interface VolunteerRoleCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  isNeeded?: boolean;
}

export default function VolunteerRoleCard({ 
  title, 
  description, 
  icon: Icon,
  isNeeded = false 
}: VolunteerRoleCardProps) {
  return (
    <Card className="bg-white p-6 rounded-xl shadow-md">
      <CardContent className="p-0 text-center">
        <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4 mx-auto">
          <Icon className="text-primary h-6 w-6" />
        </div>
        <h3 className="font-heading font-bold text-xl mb-3 text-dark">{title}</h3>
        <p className="text-dark/80 text-sm">{description}</p>
        
        {isNeeded && (
          <div className="mt-4 text-center">
            <Badge className="bg-secondary/30 text-secondary rounded-full px-3 py-1 text-xs font-medium">
              Paling Dibutuhkan
            </Badge>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
