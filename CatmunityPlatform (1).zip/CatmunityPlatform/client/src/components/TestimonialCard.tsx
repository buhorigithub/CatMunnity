import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Testimonial } from '@/lib/types';

export default function TestimonialCard({ testimonial }: { testimonial: Testimonial }) {
  const { name, role, image, quote } = testimonial;
  
  const initials = name
    .split(' ')
    .map(part => part.charAt(0))
    .join('')
    .toUpperCase();
  
  return (
    <Card className="bg-white rounded-xl p-6 shadow-md">
      <CardContent className="p-0">
        <div className="flex items-start">
          <Avatar className="w-16 h-16 rounded-full mr-4">
            <AvatarImage src={image} alt={name} className="object-cover" />
            <AvatarFallback className="bg-primary/20 text-primary">{initials}</AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-heading font-bold text-lg mb-1">{name}</h3>
            <p className="text-dark/60 text-sm mb-4">{role}</p>
            <p className="text-dark/80">{quote}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
