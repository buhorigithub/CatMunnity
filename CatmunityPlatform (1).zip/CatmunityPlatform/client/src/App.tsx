import { Route, Switch } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import MainLayout from "@/layouts/MainLayout";
import HomePage from "@/pages/HomePage";
import AboutPage from "@/pages/AboutPage";
import CampaignsPage from "@/pages/CampaignsPage";
import VolunteerPage from "@/pages/VolunteerPage";
import ImpactPage from "@/pages/ImpactPage";
import ContactPage from "@/pages/ContactPage";
import DonatePage from "@/pages/DonatePage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/campaigns" component={CampaignsPage} />
      <Route path="/volunteer" component={VolunteerPage} />
      <Route path="/impact" component={ImpactPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/donate" component={DonatePage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <MainLayout>
          <Toaster />
          <Router />
        </MainLayout>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
