import { Helmet } from 'react-helmet-async';
import { HandPlatter, Camera, Megaphone, Heart, Users, Sprout } from 'lucide-react';
import VolunteerRoleCard from '@/components/VolunteerRoleCard';
import VolunteerForm from '@/components/VolunteerForm';

export default function VolunteerPage() {
  return (
    <div className="min-h-screen py-20 bg-accent">
      <Helmet>
        <title>Jadi Relawan | Catmunitty</title>
        <meta name="description" content="Bergabunglah dalam misi memberi makan kucing jalanan dan buat perbedaan nyata." />
      </Helmet>
      
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="font-heading font-bold text-4xl md:text-5xl text-dark text-center mb-4">Jadi Relawan</h1>
          <p className="text-lg text-dark/80 text-center max-w-2xl mx-auto mb-12">
            Bergabunglah dalam misi memberi makan kucing jalanan dan buat perbedaan nyata
          </p>
          
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-12">
            <div className="md:flex">
              <div className="md:w-1/2">
                <img 
                  src="https://pixabay.com/get/g9bf0461f3ee0a0b902914ac37dddc728d942bab2e7c22cacd6f7f5b21c402353a843acf7d803e5ccf6d6264ab17c9170e340ce3e852bc9065567b6e1faa794da_1280.jpg" 
                  alt="Relawan memberi makan kucing jalanan" 
                  className="h-full w-full object-cover" 
                />
              </div>
              <div className="md:w-1/2 p-8">
                <h2 className="font-heading font-bold text-2xl mb-4 text-dark">Mengapa Menjadi Relawan?</h2>
                
                <div className="space-y-4 mb-6">
                  <div className="flex">
                    <div className="flex-shrink-0 w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center mr-4">
                      <Heart className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-heading font-medium text-lg text-dark">Berdampak Langsung</h3>
                      <p className="text-dark/80 text-sm">
                        Aksi Anda memberi makan secara langsung membuat perbedaan nyata bagi kucing jalanan.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0 w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center mr-4">
                      <Users className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-heading font-medium text-lg text-dark">Bertemu Komunitas</h3>
                      <p className="text-dark/80 text-sm">
                        Bergabung dengan kelompok orang yang memiliki kepedulian sama terhadap hewan.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0 w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center mr-4">
                      <Sprout className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-heading font-medium text-lg text-dark">Berkontribusi pada SDGs</h3>
                      <p className="text-dark/80 text-sm">
                        Membantu mencapai tujuan pembangunan berkelanjutan melalui aksi lokal.
                      </p>
                    </div>
                  </div>
                </div>
                
                <a href="#volunteer-form" className="block bg-primary hover:bg-primary/90 text-white font-medium px-6 py-3 rounded-full text-center transition duration-300">
                  Daftar Sekarang
                </a>
              </div>
            </div>
          </div>
          
          <div className="mb-12">
            <h2 className="font-heading font-bold text-3xl text-dark text-center mb-8">Peran Relawan</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <VolunteerRoleCard 
                title="Pemberi Makan" 
                description="Bertugas mengunjungi lokasi dan memberi makan kucing jalanan secara rutin sesuai jadwal. Termasuk membersihkan area makan."
                icon={HandPlatter}
                isNeeded={true}
              />
              
              <VolunteerRoleCard 
                title="Dokumentasi" 
                description="Mendokumentasikan kegiatan pemberian makan dan kondisi kucing untuk laporan transparansi dan media sosial."
                icon={Camera}
              />
              
              <VolunteerRoleCard 
                title="Kampanye" 
                description="Menyebarkan informasi tentang program, mengajak donatur, dan mengedukasi masyarakat tentang kepedulian terhadap kucing jalanan."
                icon={Megaphone}
              />
            </div>
          </div>
          
          <VolunteerForm />
        </div>
      </div>
    </div>
  );
}
