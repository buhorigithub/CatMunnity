import { Helmet } from 'react-helmet-async';
import ContactForm from '@/components/ContactForm';
import FaqItem from '@/components/FaqItem';

export default function ContactPage() {
  const faqItems = [
    {
      question: "Bagaimana cara donasi untuk kucing jalanan?",
      answer: "Anda dapat melakukan donasi melalui halaman \"Donasi\" dengan memilih kampanye yang ingin didukung. Kami menerima pembayaran melalui transfer bank, e-wallet, dan kartu kredit. Semua donasi akan mendapatkan laporan penggunaan dana."
    },
    {
      question: "Bagaimana proses menjadi relawan?",
      answer: "Setelah mengisi formulir pendaftaran di halaman \"Relawan\", tim kami akan menghubungi Anda dalam 2-3 hari kerja untuk interview singkat. Jika sesuai, Anda akan mendapatkan orientasi dan dapat mulai berpartisipasi dalam kegiatan."
    },
    {
      question: "Apa saja yang termasuk dalam program pemberian pangan?",
      answer: "Program pemberian pangan meliputi makanan kering (dry food) berkualitas, makanan basah untuk kasus tertentu, air bersih, dan vitamin jika diperlukan. Kami juga menyediakan wadah makanan dan tempat pemberian makan yang bersih di setiap lokasi."
    },
    {
      question: "Bagaimana cara mengusulkan lokasi baru untuk pemberian pangan?",
      answer: "Anda dapat mengusulkan lokasi baru melalui formulir kontak di halaman ini. Berikan informasi detail tentang lokasi, perkiraan jumlah kucing, dan kondisi kucing di sana. Tim kami akan melakukan survei untuk menentukan kelayakan program."
    },
    {
      question: "Apakah saya bisa berpartisipasi jika berada di luar kota yang terdaftar?",
      answer: "Tentu! Anda dapat memulai inisiatif di kota Anda dengan panduan dari tim kami. Kami dapat memberikan pelatihan online dan materi pendukung untuk membantu Anda memulai program pemberian pangan di lokasi Anda."
    }
  ];

  return (
    <div className="min-h-screen py-20 bg-accent">
      <Helmet>
        <title>Kontak Kami | Catmunitty</title>
        <meta name="description" content="Ada pertanyaan atau ingin berkolaborasi? Jangan ragu untuk menghubungi kami." />
      </Helmet>
      
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="font-heading font-bold text-4xl md:text-5xl text-dark text-center mb-4">Hubungi Kami</h1>
          <p className="text-lg text-dark/80 text-center max-w-2xl mx-auto mb-12">
            Ada pertanyaan atau ingin berkolaborasi? Jangan ragu untuk menghubungi kami
          </p>
          
          <ContactForm />
          
          <div className="mt-16">
            <h2 className="font-heading font-bold text-3xl text-dark text-center mb-8">FAQ</h2>
            
            <div className="space-y-4">
              {faqItems.map((item, index) => (
                <FaqItem 
                  key={index}
                  question={item.question}
                  answer={item.answer}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
