import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Helmet } from 'react-helmet-async';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import CampaignCard from '@/components/CampaignCard';
import { Campaign } from '@/lib/types';
import { ChevronDown } from 'lucide-react';

export default function CampaignsPage() {
  const [filter, setFilter] = useState('all');
  
  const { data: campaigns, isLoading } = useQuery<Campaign[]>({
    queryKey: ['/api/campaigns'],
  });
  
  const filteredCampaigns = campaigns?.filter(campaign => {
    if (filter === 'all') return true;
    if (filter === 'urgent') return campaign.isUrgent;
    return campaign.location.toLowerCase().includes(filter.toLowerCase());
  });
  
  const locations = ['Jakarta', 'Bandung', 'Surabaya'];

  return (
    <div className="min-h-screen py-20 bg-accent">
      <Helmet>
        <title>Kampanye | Catmunitty</title>
        <meta name="description" content="Pilih kampanye yang ingin Anda dukung untuk memberi makan kucing jalanan." />
      </Helmet>
      
      <div className="container mx-auto px-4">
        <h1 className="font-heading font-bold text-4xl md:text-5xl text-dark text-center mb-4">Kampanye Aktif</h1>
        <p className="text-lg text-dark/80 text-center max-w-2xl mx-auto mb-12">
          Pilih kampanye yang ingin Anda dukung untuk memberi makan kucing jalanan
        </p>
        
        <div className="mb-8">
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Button
              variant={filter === 'all' ? 'default' : 'outline'}
              className={filter === 'all' ? 'bg-primary text-white' : 'bg-white text-dark hover:bg-primary/10'}
              onClick={() => setFilter('all')}
            >
              Semua Kampanye
            </Button>
            <Button
              variant={filter === 'urgent' ? 'default' : 'outline'}
              className={filter === 'urgent' ? 'bg-primary text-white' : 'bg-white text-dark hover:bg-primary/10'}
              onClick={() => setFilter('urgent')}
            >
              Mendesak
            </Button>
            {locations.map(location => (
              <Button
                key={location}
                variant={filter === location.toLowerCase() ? 'default' : 'outline'}
                className={filter === location.toLowerCase() ? 'bg-primary text-white' : 'bg-white text-dark hover:bg-primary/10'}
                onClick={() => setFilter(location.toLowerCase())}
              >
                {location}
              </Button>
            ))}
          </div>
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, index) => (
              <div key={index} className="bg-white rounded-xl h-96 animate-pulse"></div>
            ))}
          </div>
        ) : filteredCampaigns && filteredCampaigns.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCampaigns.map(campaign => (
              <CampaignCard key={campaign.id} campaign={campaign} />
            ))}
          </div>
        ) : (
          <div className="text-center p-12 bg-white rounded-xl shadow-md">
            <p className="text-dark/80">Tidak ada kampanye yang ditemukan dengan filter yang dipilih.</p>
          </div>
        )}
        
        {filteredCampaigns && filteredCampaigns.length > 0 && (
          <div className="text-center mt-12">
            <Button variant="outline" className="border border-primary text-primary hover:bg-primary/5 font-medium px-8 py-3 rounded-full inline-flex items-center">
              Lihat Lebih Banyak
              <ChevronDown className="ml-2 h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
