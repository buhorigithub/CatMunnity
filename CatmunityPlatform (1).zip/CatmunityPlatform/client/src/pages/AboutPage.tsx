import { Helmet } from 'react-helmet-async';
import { Eye, Flag, CheckCircle } from 'lucide-react';
import TeamMemberCard from '@/components/TeamMemberCard';
import { Card, CardContent } from '@/components/ui/card';

export default function AboutPage() {
  const teamMembers = [
    {
      name: "Sarah Damayanti",
      role: "Founder & CEO",
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
      description: "Pecinta kucing dengan pengalaman 10 tahun di bidang kesejahteraan hewan."
    },
    {
      name: "Budi Santoso",
      role: "Operations Director",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
      description: "Ahli logistik dengan passion untuk bantuan kemanusiaan dan hewan."
    },
    {
      name: "Drh. Maya Wijaya",
      role: "Veterinary Advisor",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
      description: "Dokter hewan berpengalaman yang mengadvokasi kesejahteraan kucing jalanan."
    }
  ];
  
  const partners = [
    "Pet Store ID",
    "Rumah Kucing",
    "Meow Foundation",
    "Dokter Hewan Peduli"
  ];

  return (
    <div className="min-h-screen py-20 bg-accent">
      <Helmet>
        <title>Tentang Kami | Catmunitty</title>
        <meta name="description" content="Catmunitty adalah platform patungan yang didedikasikan untuk membantu kucing jalanan di seluruh Indonesia." />
      </Helmet>
      
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="font-heading font-bold text-4xl md:text-5xl text-dark text-center mb-8">Tentang Catmunitty</h1>
          
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-12">
            <div className="md:flex">
              <div className="md:w-1/2">
                <img 
                  src="https://images.unsplash.com/photo-1606214174585-fe31582dc6ee?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                  alt="Relawan Catmunitty" 
                  className="h-full w-full object-cover" 
                />
              </div>
              <div className="md:w-1/2 p-8">
                <h2 className="font-heading font-bold text-2xl mb-4 text-dark">Siapa Kami</h2>
                <p className="text-dark/80 mb-4">
                  Catmunitty adalah platform patungan yang didedikasikan untuk membantu kucing jalanan di seluruh Indonesia. 
                  Didirikan pada tahun 2021 oleh sekelompok pencinta kucing, kami bertujuan untuk menciptakan jaringan peduli yang berkelanjutan.
                </p>
                <p className="text-dark/80 mb-4">
                  Kami percaya bahwa melalui kolaborasi komunitas, kita dapat membuat perubahan nyata bagi makhluk jalanan yang sering terabaikan.
                </p>
                <p className="text-dark/80">
                  Catmunitty bekerja sama dengan berbagai komunitas lokal, dokter hewan, dan relawan untuk memastikan bantuan yang diberikan tepat sasaran dan berkelanjutan.
                </p>
              </div>
            </div>
          </div>
          
          <div className="mb-12">
            <h2 className="font-heading font-bold text-3xl text-dark text-center mb-8">Visi & Misi</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-8 rounded-xl shadow-md">
                <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Eye className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-heading font-bold text-xl mb-4 text-dark text-center">Visi</h3>
                <p className="text-dark/80 text-center">
                  Menciptakan lingkungan di mana setiap kucing jalanan mendapatkan akses ke makanan, perawatan, dan perlindungan yang layak melalui kesadaran dan partisipasi masyarakat.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-xl shadow-md">
                <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Flag className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-heading font-bold text-xl mb-4 text-dark text-center">Misi</h3>
                <ul className="text-dark/80 space-y-2">
                  <li className="flex">
                    <CheckCircle className="text-primary h-5 w-5 mt-0.5 mr-2 flex-shrink-0" />
                    <span>Membangun platform patungan transparan untuk bantuan pangan kucing jalanan</span>
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-primary h-5 w-5 mt-0.5 mr-2 flex-shrink-0" />
                    <span>Memberdayakan relawan lokal untuk aksi nyata di komunitas mereka</span>
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-primary h-5 w-5 mt-0.5 mr-2 flex-shrink-0" />
                    <span>Mengedukasi masyarakat tentang pentingnya kesejahteraan hewan</span>
                  </li>
                  <li className="flex">
                    <CheckCircle className="text-primary h-5 w-5 mt-0.5 mr-2 flex-shrink-0" />
                    <span>Berkolaborasi dengan pihak terkait untuk program sterilisasi dan vaksinasi</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="mb-12">
            <h2 className="font-heading font-bold text-3xl text-dark text-center mb-8">Tim Kami</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {teamMembers.map((member, index) => (
                <TeamMemberCard 
                  key={index}
                  name={member.name}
                  role={member.role}
                  image={member.image}
                  description={member.description}
                />
              ))}
            </div>
          </div>
          
          <div>
            <h2 className="font-heading font-bold text-3xl text-dark text-center mb-8">Partner Kami</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {partners.map((partner, index) => (
                <Card key={index} className="bg-white p-4 rounded-xl shadow-md">
                  <CardContent className="p-0 flex items-center justify-center h-24">
                    <span className="font-heading font-bold text-dark/70">{partner}</span>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
