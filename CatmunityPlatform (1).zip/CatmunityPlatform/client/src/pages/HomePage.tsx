import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Helmet } from 'react-helmet-async';
import { 
  UtensilsCrossed, 
  Building2, 
  Sprout, 
  Users,
  ArrowRight,
  CheckCircle
} from 'lucide-react';

import HeroSection from '@/components/HeroSection';
import SdgCard from '@/components/SdgCard';
import CampaignCard from '@/components/CampaignCard';
import ImpactCounter from '@/components/ImpactCounter';
import TestimonialCard from '@/components/TestimonialCard';
import { Button } from '@/components/ui/button';
import { Campaign, Testimonial } from '@/lib/types';

export default function HomePage() {
  const { data: featuredCampaign, isLoading: isLoadingCampaign } = useQuery<Campaign>({
    queryKey: ['/api/campaigns/featured'],
  });
  
  const { data: stats, isLoading: isLoadingStats } = useQuery<{
    cats: number,
    locations: number,
    volunteers: number
  }>({
    queryKey: ['/api/stats'],
  });
  
  const { data: testimonials, isLoading: isLoadingTestimonials } = useQuery<Testimonial[]>({
    queryKey: ['/api/testimonials'],
  });

  return (
    <>
      <Helmet>
        <title>Catmunitty - Bersama Peduli Makhluk Jalanan</title>
        <meta name="description" content="Platform patungan untuk pangan kucing terlantar. Bersama kita buat perbedaan untuk makhluk jalanan." />
      </Helmet>
      
      {/* Hero Section */}
      <HeroSection 
        title="Bersama Peduli Makhluk Jalanan" 
        subtitle="Gerakan Patungan untuk Pangan Kucing Terlantar"
        backgroundImage="https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
      />
      
      {/* Mission Statement */}
      <div className="bg-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="font-heading font-bold text-3xl md:text-4xl mb-6 text-dark">Misi Kami</h2>
            <p className="text-lg text-dark/80 mb-8">
              Catmunitty adalah platform patungan untuk membantu memberi makan kucing-kucing terlantar di jalanan. 
              Kami berkomitmen untuk mengurangi penderitaan kucing jalanan melalui kolaborasi komunitas dan tindakan nyata.
            </p>
            
            <div className="flex flex-wrap justify-center gap-8 mt-12">
              <SdgCard 
                number={2}
                title="Zero Hunger"
                description="Mengurangi kelaparan bagi semua makhluk hidup"
                icon={UtensilsCrossed}
                color="sdg2"
              />
              
              <SdgCard 
                number={11}
                title="Sustainable Cities"
                description="Membangun lingkungan kota yang bersih dan seimbang"
                icon={Building2}
                color="sdg11"
              />
              
              <SdgCard 
                number={15}
                title="Life on Land"
                description="Melindungi ekosistem dan kesejahteraan hidup di darat"
                icon={Sprout}
                color="sdg15"
              />
              
              <SdgCard 
                number={17}
                title="Partnerships"
                description="Membangun kolaborasi untuk tujuan sosial bersama"
                icon={Users}
                color="sdg17"
              />
            </div>
          </div>
        </div>
      </div>
      
      {/* Featured Campaign */}
      <div className="bg-accent py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-heading font-bold text-3xl md:text-4xl mb-3 text-dark">Kampanye Utama</h2>
            <p className="text-lg text-dark/80 max-w-2xl mx-auto">
              Mari berpartisipasi dalam kampanye pengumpulan dana untuk memberi makan kucing jalanan
            </p>
          </div>
          
          {isLoadingCampaign ? (
            <div className="max-w-5xl mx-auto h-80 bg-white/50 rounded-2xl animate-pulse"></div>
          ) : featuredCampaign ? (
            <CampaignCard campaign={featuredCampaign} featured />
          ) : (
            <div className="max-w-5xl mx-auto text-center p-8 bg-white rounded-2xl shadow-md">
              <p className="text-dark/80">Tidak ada kampanye yang ditampilkan saat ini.</p>
            </div>
          )}
        </div>
      </div>
      
      {/* Impact Summary */}
      <div className="bg-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-heading font-bold text-3xl md:text-4xl mb-3 text-dark">Dampak Kita</h2>
            <p className="text-lg text-dark/80 max-w-2xl mx-auto">
              Bersama-sama kita telah membuat perubahan nyata untuk kucing jalanan
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {isLoadingStats ? (
              <>
                <div className="bg-accent rounded-xl p-8 h-32 animate-pulse"></div>
                <div className="bg-accent rounded-xl p-8 h-32 animate-pulse"></div>
                <div className="bg-accent rounded-xl p-8 h-32 animate-pulse"></div>
              </>
            ) : (
              <>
                <ImpactCounter 
                  value={stats?.cats || 1250} 
                  label="Kucing Terbantu" 
                  delay={0}
                />
                <ImpactCounter 
                  value={stats?.locations || 25} 
                  label="Lokasi Pemberian Pangan" 
                  delay={200}
                />
                <ImpactCounter 
                  value={stats?.volunteers || 350} 
                  label="Relawan Aktif" 
                  delay={400}
                />
              </>
            )}
          </div>
          
          <div className="text-center mt-12">
            <Link href="/impact">
              <Button variant="link" className="text-primary hover:text-primary/80 font-medium inline-flex items-center">
                Lihat laporan lengkap
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Testimonials */}
      <div className="bg-primary/10 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-heading font-bold text-3xl md:text-4xl mb-3 text-dark">Cerita Keberhasilan</h2>
            <p className="text-lg text-dark/80 max-w-2xl mx-auto">
              Kisah inspiratif dari para relawan dan kucing yang terbantu
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {isLoadingTestimonials ? (
              <>
                <div className="bg-white rounded-xl p-6 h-40 animate-pulse"></div>
                <div className="bg-white rounded-xl p-6 h-40 animate-pulse"></div>
              </>
            ) : testimonials && testimonials.length > 0 ? (
              testimonials.slice(0, 2).map((testimonial) => (
                <TestimonialCard key={testimonial.id} testimonial={testimonial} />
              ))
            ) : (
              <div className="md:col-span-2 text-center p-8 bg-white rounded-xl shadow-md">
                <p className="text-dark/80">Belum ada cerita keberhasilan yang ditampilkan.</p>
              </div>
            )}
          </div>
          
          <div className="text-center mt-12">
            <Link href="/impact#testimonials">
              <Button variant="link" className="text-primary hover:text-primary/80 font-medium inline-flex items-center">
                Baca lebih banyak cerita
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Call to Action */}
      <div className="bg-primary py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center text-white">
            <h2 className="font-heading font-bold text-3xl md:text-4xl mb-6">Bergabunglah dengan Gerakan Ini!</h2>
            <p className="text-lg mb-8">
              Setiap kontribusi membuat perbedaan besar bagi kucing jalanan. Donasi, menjadi relawan, atau sebarkan informasi.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/donate">
                <Button className="bg-white text-primary hover:bg-accent font-bold px-8 py-3 rounded-full text-center transition duration-300 w-full sm:w-auto">
                  Donasi Sekarang
                </Button>
              </Link>
              <Link href="/volunteer">
                <Button variant="outline" className="bg-transparent border-2 border-white text-white hover:bg-white/10 font-bold px-8 py-3 rounded-full text-center transition duration-300 w-full sm:w-auto">
                  Jadi Relawan
                </Button>
              </Link>
              <Button variant="outline" className="bg-transparent border-2 border-white text-white hover:bg-white/10 font-bold px-8 py-3 rounded-full text-center transition duration-300 w-full sm:w-auto">
                Bagikan
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
