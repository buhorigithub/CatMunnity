import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Helmet } from 'react-helmet-async';
import { useLocation } from 'wouter';
import DonationForm from '@/components/DonationForm';
import CampaignCard from '@/components/CampaignCard';
import { Card, CardContent } from '@/components/ui/card';
import { Campaign } from '@/lib/types';
import { Heart, HeartHandshake, PawPrint } from 'lucide-react';

export default function DonatePage() {
  const [, params] = useLocation();
  const campaignId = new URLSearchParams(params).get('campaign');
  
  const { data: campaigns, isLoading: isLoadingCampaigns } = useQuery<Campaign[]>({
    queryKey: ['/api/campaigns'],
  });
  
  const selectedCampaign = campaigns?.find(campaign => campaign.id.toString() === campaignId);
  
  const impactItems = [
    {
      value: "Rp 50.000",
      description: "Dapat memberi makan 5 kucing jalanan selama 1 minggu",
      icon: Heart
    },
    {
      value: "Rp 100.000",
      description: "Dapat memberi makan 10 kucing jalanan selama 1 minggu",
      icon: HeartHandshake
    },
    {
      value: "Rp 250.000",
      description: "Dapat memberi makan 25 kucing jalanan selama 1 minggu dan membantu pembuatan shelter sederhana",
      icon: PawPrint
    }
  ];

  return (
    <div className="min-h-screen py-20 bg-accent">
      <Helmet>
        <title>Donasi | Catmunitty</title>
        <meta name="description" content="Bantu memberi makan kucing jalanan dengan donasi Anda. Setiap kontribusi membuat perbedaan." />
      </Helmet>
      
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h1 className="font-heading font-bold text-4xl md:text-5xl text-dark text-center mb-4">Donasi</h1>
          <p className="text-lg text-dark/80 text-center max-w-2xl mx-auto mb-12">
            Bantu memberi makan kucing jalanan dan membuat perbedaan bagi kehidupan mereka
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {impactItems.map((item, index) => (
              <Card key={index} className="bg-white rounded-xl shadow-md">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                    <item.icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-heading font-bold text-xl mb-2 text-dark">{item.value}</h3>
                  <p className="text-dark/80 text-sm">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h2 className="font-heading font-bold text-2xl mb-6 text-dark">Buat Donasi</h2>
              <DonationForm selectedCampaign={selectedCampaign} />
            </div>
            
            <div>
              <h2 className="font-heading font-bold text-2xl mb-6 text-dark">
                {selectedCampaign ? 'Kampanye Yang Didukung' : 'Kampanye Yang Membutuhkan'}
              </h2>
              
              {isLoadingCampaigns ? (
                <div className="bg-white rounded-xl h-96 animate-pulse"></div>
              ) : selectedCampaign ? (
                <CampaignCard campaign={selectedCampaign} />
              ) : campaigns && campaigns.length > 0 ? (
                <div className="space-y-6">
                  {campaigns
                    .filter(campaign => campaign.isUrgent)
                    .slice(0, 2)
                    .map(campaign => (
                      <CampaignCard key={campaign.id} campaign={campaign} />
                    ))}
                </div>
              ) : (
                <div className="text-center p-8 bg-white rounded-xl shadow-md">
                  <p className="text-dark/80">Tidak ada kampanye yang ditampilkan saat ini.</p>
                </div>
              )}
            </div>
          </div>
          
          <div className="mt-12 bg-white p-6 rounded-xl shadow-md">
            <h2 className="font-heading font-bold text-xl mb-4 text-dark">Catatan Penting</h2>
            <div className="space-y-3 text-dark/80">
              <p>• 100% donasi Anda akan digunakan untuk memberi makan kucing jalanan.</p>
              <p>• Semua donatur akan mendapatkan laporan penggunaan dana melalui email.</p>
              <p>• Anda dapat memilih kampanye spesifik atau membiarkan kami mengalokasikan donasi ke kampanye yang paling membutuhkan.</p>
              <p>• Donasi Anda dikelola dengan transparan dan dapat dilacak melalui halaman Dampak.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
