import { useQuery } from '@tanstack/react-query';
import { Helmet } from 'react-helmet-async';
import { 
  UtensilsCrossed, 
  Building2, 
  Sprout, 
  Users, 
  CheckCircle,
  ArrowRight,
  Download
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import ImpactCounter from '@/components/ImpactCounter';
import { Testimonial } from '@/lib/types';

export default function ImpactPage() {
  const { data: stats, isLoading: isLoadingStats } = useQuery<{
    cats: number,
    locations: number,
    volunteers: number
  }>({
    queryKey: ['/api/stats'],
  });
  
  const { data: successStories, isLoading: isLoadingStories } = useQuery<{
    id: number;
    title: string;
    description: string;
    image: string;
  }[]>({
    queryKey: ['/api/success-stories'],
  });
  
  const { data: financialReports, isLoading: isLoadingReports } = useQuery<{
    period: string;
    totalDonations: number;
    expenses: {
      category: string;
      amount: number;
      percentage: number;
    }[];
  }[]>({
    queryKey: ['/api/financial-reports'],
  });

  return (
    <div className="min-h-screen py-20 bg-accent">
      <Helmet>
        <title>Dampak | Catmunitty</title>
        <meta name="description" content="Melihat perubahan nyata yang telah kita buat bersama untuk kucing jalanan." />
      </Helmet>
      
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="font-heading font-bold text-4xl md:text-5xl text-dark text-center mb-4">Dampak Kita</h1>
          <p className="text-lg text-dark/80 text-center max-w-2xl mx-auto mb-12">
            Melihat perubahan nyata yang telah kita buat bersama untuk kucing jalanan
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {isLoadingStats ? (
              <>
                <div className="bg-white rounded-xl p-8 h-32 animate-pulse"></div>
                <div className="bg-white rounded-xl p-8 h-32 animate-pulse"></div>
                <div className="bg-white rounded-xl p-8 h-32 animate-pulse"></div>
              </>
            ) : (
              <>
                <ImpactCounter 
                  value={stats?.cats || 1250} 
                  label="Kucing Terbantu" 
                  delay={0}
                  duration={2500}
                />
                <ImpactCounter 
                  value={stats?.locations || 25} 
                  label="Lokasi Pemberian Pangan" 
                  delay={300}
                  duration={2500}
                />
                <ImpactCounter 
                  value={stats?.volunteers || 350} 
                  label="Relawan Aktif" 
                  delay={600}
                  duration={2500}
                />
              </>
            )}
          </div>
          
          <div className="mb-12" id="sdg-contributions">
            <h2 className="font-heading font-bold text-3xl text-dark text-center mb-8">Kontribusi Terhadap SDGs</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card className="bg-white p-6 rounded-xl shadow-md">
                <CardContent className="p-0">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center bg-[#DDA63A] text-white mr-4">
                      <UtensilsCrossed className="h-5 w-5" />
                    </div>
                    <h3 className="font-heading font-bold text-xl text-dark">SDG 2: Zero Hunger</h3>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </div>
                      <p className="text-dark/80 text-sm">Memberi makan 1,250+ kucing jalanan secara rutin</p>
                    </div>
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </div>
                      <p className="text-dark/80 text-sm">Mendistribusikan 2,500+ kg makanan kucing</p>
                    </div>
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </div>
                      <p className="text-dark/80 text-sm">Meningkatkan kesehatan dan daya tahan tubuh kucing jalanan</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-white p-6 rounded-xl shadow-md">
                <CardContent className="p-0">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center bg-[#F99D26] text-white mr-4">
                      <Building2 className="h-5 w-5" />
                    </div>
                    <h3 className="font-heading font-bold text-xl text-dark">SDG 11: Sustainable Cities</h3>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </div>
                      <p className="text-dark/80 text-sm">Mengurangi persebaran penyakit pada populasi kucing jalanan</p>
                    </div>
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </div>
                      <p className="text-dark/80 text-sm">Menciptakan harmoni antara kucing jalanan dan masyarakat kota</p>
                    </div>
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </div>
                      <p className="text-dark/80 text-sm">Memasang 15 feeding station permanen yang ramah lingkungan</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-white p-6 rounded-xl shadow-md">
                <CardContent className="p-0">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center bg-[#56C02B] text-white mr-4">
                      <Sprout className="h-5 w-5" />
                    </div>
                    <h3 className="font-heading font-bold text-xl text-dark">SDG 15: Life on Land</h3>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </div>
                      <p className="text-dark/80 text-sm">Berkolaborasi dengan 5 klinik hewan untuk program sterilisasi</p>
                    </div>
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </div>
                      <p className="text-dark/80 text-sm">Membantu 120+ kucing jalanan mendapatkan perawatan kesehatan</p>
                    </div>
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </div>
                      <p className="text-dark/80 text-sm">Mengontrol populasi kucing jalanan secara humanis</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-white p-6 rounded-xl shadow-md">
                <CardContent className="p-0">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center bg-[#19486A] text-white mr-4">
                      <Users className="h-5 w-5" />
                    </div>
                    <h3 className="font-heading font-bold text-xl text-dark">SDG 17: Partnerships</h3>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </div>
                      <p className="text-dark/80 text-sm">Bermitra dengan 12 komunitas pecinta kucing lokal</p>
                    </div>
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </div>
                      <p className="text-dark/80 text-sm">Menjalin kerjasama dengan 8 toko pet food untuk donasi pangan</p>
                    </div>
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </div>
                      <p className="text-dark/80 text-sm">Mengadakan 15 sesi edukasi kepada masyarakat</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
          
          <div className="mb-12" id="testimonials">
            <h2 className="font-heading font-bold text-3xl text-dark text-center mb-8">Kisah Sukses</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {isLoadingStories ? (
                <>
                  <div className="bg-white rounded-xl h-80 animate-pulse"></div>
                  <div className="bg-white rounded-xl h-80 animate-pulse"></div>
                </>
              ) : successStories && successStories.length > 0 ? (
                successStories.map((story) => (
                  <Card key={story.id} className="bg-white rounded-xl overflow-hidden shadow-md">
                    <img 
                      src={story.image} 
                      alt={story.title} 
                      className="w-full h-48 object-cover" 
                    />
                    <CardContent className="p-6">
                      <h3 className="font-heading font-bold text-xl mb-2 text-dark">{story.title}</h3>
                      <p className="text-dark/80 text-sm mb-4">{story.description}</p>
                      <Link href={`/impact/stories/${story.id}`}>
                        <Button variant="link" className="text-primary hover:underline font-medium inline-flex items-center text-sm p-0">
                          Baca kisah lengkap
                          <ArrowRight className="ml-1 h-4 w-4" />
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="md:col-span-2 text-center p-8 bg-white rounded-xl shadow-md">
                  <p className="text-dark/80">Belum ada kisah sukses yang ditampilkan.</p>
                </div>
              )}
            </div>
          </div>
          
          <div id="financial-reports">
            <h2 className="font-heading font-bold text-3xl text-dark text-center mb-8">Laporan Transparansi</h2>
            
            {isLoadingReports ? (
              <div className="bg-white rounded-xl h-80 animate-pulse mb-8"></div>
            ) : financialReports && financialReports.length > 0 ? (
              <Card className="bg-white rounded-xl p-6 shadow-md mb-8">
                <CardContent className="p-0">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-heading font-bold text-xl text-dark">{financialReports[0].period}</h3>
                    <Button variant="link" className="text-primary hover:underline font-medium text-sm inline-flex items-center p-0">
                      <Download className="mr-2 h-4 w-4" />
                      Unduh Laporan
                    </Button>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="font-medium">Total Donasi Terkumpul</span>
                        <span className="font-bold">Rp {financialReports[0].totalDonations.toLocaleString('id-ID')}</span>
                      </div>
                      <Progress value={100} className="h-2 bg-gray-200" />
                    </div>
                    
                    {financialReports[0].expenses.map((expense, index) => (
                      <div key={index}>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium">{expense.category}</span>
                          <span className="font-bold">Rp {expense.amount.toLocaleString('id-ID')} ({expense.percentage}%)</span>
                        </div>
                        <Progress value={expense.percentage} className="h-2 bg-gray-200" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="text-center p-8 bg-white rounded-xl shadow-md mb-8">
                <p className="text-dark/80">Belum ada laporan keuangan yang ditampilkan.</p>
              </div>
            )}
            
            <div className="text-center">
              <Button variant="link" className="text-primary hover:text-primary/80 font-medium inline-flex items-center">
                Lihat semua laporan
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
