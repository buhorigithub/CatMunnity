import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Campaigns Table
export const campaigns = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  image: text("image").notNull(),
  isUrgent: boolean("is_urgent").default(false),
  daysLeft: integer("days_left").notNull(),
  targetAmount: integer("target_amount").notNull(),
  currentAmount: integer("current_amount").default(0),
  donorCount: integer("donor_count").default(0),
  isFeatured: boolean("is_featured").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Donations Table
export const donations = pgTable("donations", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id"),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  amount: text("amount").notNull(),
  paymentMethod: text("payment_method").notNull(),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Volunteers Table
export const volunteers = pgTable("volunteers", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  location: text("location").notNull(),
  role: text("role").notNull(),
  experience: text("experience"),
  availability: text("availability").notNull(),
  termsAgreed: boolean("terms_agreed").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Contact Messages Table
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Testimonials Table
export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  image: text("image").notNull(),
  quote: text("quote").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Success Stories Table
export const successStories = pgTable("success_stories", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  image: text("image").notNull(),
  fullStory: text("full_story"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Financial Reports Table
export const financialReports = pgTable("financial_reports", {
  id: serial("id").primaryKey(),
  period: text("period").notNull(),
  totalDonations: integer("total_donations").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Expenses Table
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  reportId: integer("report_id").notNull(),
  category: text("category").notNull(),
  amount: integer("amount").notNull(),
  percentage: doublePrecision("percentage").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Users Table (keeping existing users table)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Insert schemas using drizzle-zod
export const insertCampaignSchema = createInsertSchema(campaigns).omit({
  id: true,
  currentAmount: true,
  donorCount: true,
  createdAt: true,
});

export const insertDonationSchema = createInsertSchema(donations).omit({
  id: true,
  createdAt: true,
});

export const insertVolunteerSchema = createInsertSchema(volunteers).omit({
  id: true,
  createdAt: true,
});

export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Export types
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Campaign = typeof campaigns.$inferSelect;
export type InsertDonation = z.infer<typeof insertDonationSchema>;
export type Donation = typeof donations.$inferSelect;
export type InsertVolunteer = z.infer<typeof insertVolunteerSchema>;
export type Volunteer = typeof volunteers.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contacts.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Testimonial = typeof testimonials.$inferSelect;
export type SuccessStory = typeof successStories.$inferSelect;
export type FinancialReport = typeof financialReports.$inferSelect;
export type Expense = typeof expenses.$inferSelect;
