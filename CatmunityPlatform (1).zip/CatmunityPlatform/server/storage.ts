import { 
  users, 
  campaigns, 
  donations, 
  volunteers, 
  contacts, 
  testimonials, 
  successStories, 
  financialReports,
  expenses,
  type User, 
  type InsertUser,
  type Campaign,
  type InsertCampaign,
  type Donation,
  type InsertDonation,
  type Volunteer,
  type InsertVolunteer,
  type Contact,
  type InsertContact,
  type Testimonial,
  type SuccessStory,
  type FinancialReport,
  type Expense
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Campaign operations
  getAllCampaigns(): Promise<Campaign[]>;
  getCampaign(id: number): Promise<Campaign | undefined>;
  getFeaturedCampaign(): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaignAmount(id: number, amount: number): Promise<Campaign | undefined>;
  
  // Donation operations
  createDonation(donation: InsertDonation): Promise<Donation>;
  
  // Volunteer operations
  createVolunteer(volunteer: InsertVolunteer): Promise<Volunteer>;
  
  // Contact operations
  createContactMessage(contact: InsertContact): Promise<Contact>;
  
  // Other operations
  getImpactStats(): Promise<{ cats: number, locations: number, volunteers: number }>;
  getAllTestimonials(): Promise<Testimonial[]>;
  getAllSuccessStories(): Promise<SuccessStory[]>;
  getFinancialReports(): Promise<FinancialReport[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private campaigns: Map<number, Campaign>;
  private donations: Map<number, Donation>;
  private volunteers: Map<number, Volunteer>;
  private contacts: Map<number, Contact>;
  private testimonials: Map<number, Testimonial>;
  private successStories: Map<number, SuccessStory>;
  private financialReports: Map<number, FinancialReport>;
  private expenses: Map<number, Expense>;
  
  private userIdCounter: number;
  private campaignIdCounter: number;
  private donationIdCounter: number;
  private volunteerIdCounter: number;
  private contactIdCounter: number;
  private testimonialIdCounter: number;
  private storyIdCounter: number;
  private reportIdCounter: number;
  private expenseIdCounter: number;

  constructor() {
    this.users = new Map();
    this.campaigns = new Map();
    this.donations = new Map();
    this.volunteers = new Map();
    this.contacts = new Map();
    this.testimonials = new Map();
    this.successStories = new Map();
    this.financialReports = new Map();
    this.expenses = new Map();
    
    this.userIdCounter = 1;
    this.campaignIdCounter = 1;
    this.donationIdCounter = 1;
    this.volunteerIdCounter = 1;
    this.contactIdCounter = 1;
    this.testimonialIdCounter = 1;
    this.storyIdCounter = 1;
    this.reportIdCounter = 1;
    this.expenseIdCounter = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Campaign operations
  async getAllCampaigns(): Promise<Campaign[]> {
    return Array.from(this.campaigns.values());
  }
  
  async getCampaign(id: number): Promise<Campaign | undefined> {
    return this.campaigns.get(id);
  }
  
  async getFeaturedCampaign(): Promise<Campaign | undefined> {
    return Array.from(this.campaigns.values()).find(campaign => campaign.isFeatured);
  }
  
  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const id = this.campaignIdCounter++;
    const now = new Date().toISOString();
    const campaign: Campaign = { 
      ...insertCampaign, 
      id, 
      currentAmount: 0, 
      donorCount: 0, 
      createdAt: now 
    };
    this.campaigns.set(id, campaign);
    return campaign;
  }
  
  async updateCampaignAmount(id: number, amount: number): Promise<Campaign | undefined> {
    const campaign = this.campaigns.get(id);
    if (!campaign) return undefined;
    
    const updatedCampaign: Campaign = {
      ...campaign,
      currentAmount: campaign.currentAmount + amount,
      donorCount: campaign.donorCount + 1
    };
    
    this.campaigns.set(id, updatedCampaign);
    return updatedCampaign;
  }
  
  // Donation operations
  async createDonation(insertDonation: InsertDonation): Promise<Donation> {
    const id = this.donationIdCounter++;
    const now = new Date().toISOString();
    // Convert amount to number if it's a string
    const amount = typeof insertDonation.amount === 'string' 
      ? parseInt(insertDonation.amount) 
      : insertDonation.amount;
      
    const donation: Donation = { 
      ...insertDonation, 
      id, 
      amount,
      createdAt: now 
    };
    this.donations.set(id, donation);
    return donation;
  }
  
  // Volunteer operations
  async createVolunteer(insertVolunteer: InsertVolunteer): Promise<Volunteer> {
    const id = this.volunteerIdCounter++;
    const now = new Date().toISOString();
    const volunteer: Volunteer = { 
      ...insertVolunteer, 
      id, 
      createdAt: now 
    };
    this.volunteers.set(id, volunteer);
    return volunteer;
  }
  
  // Contact operations
  async createContactMessage(insertContact: InsertContact): Promise<Contact> {
    const id = this.contactIdCounter++;
    const now = new Date().toISOString();
    const contact: Contact = { 
      ...insertContact, 
      id, 
      createdAt: now 
    };
    this.contacts.set(id, contact);
    return contact;
  }
  
  // Other operations
  async getImpactStats(): Promise<{ cats: number, locations: number, volunteers: number }> {
    return {
      cats: 1250,
      locations: 25,
      volunteers: this.volunteers.size || 350
    };
  }
  
  async getAllTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values());
  }
  
  async getAllSuccessStories(): Promise<SuccessStory[]> {
    return Array.from(this.successStories.values());
  }
  
  async getFinancialReports(): Promise<FinancialReport[]> {
    const reports = Array.from(this.financialReports.values());
    
    // Add expenses to each report
    return reports.map(report => {
      const reportExpenses = Array.from(this.expenses.values())
        .filter(expense => expense.reportId === report.id);
      
      return {
        ...report,
        expenses: reportExpenses
      };
    });
  }
  
  // Helper method to initialize sample data
  private initializeSampleData() {
    // Sample campaigns
    const campaigns: Omit<Campaign, 'id'>[] = [
      {
        title: "Bantuan Pangan Kucing Area Pasar Minggu",
        description: "Membantu memberi makan 35 kucing terlantar di sekitar Pasar Minggu yang kekurangan makanan akibat pedagang yang mulai sepi.",
        location: "Jakarta",
        image: "https://images.unsplash.com/photo-1561948955-570b270e7c36?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=350",
        isUrgent: true,
        daysLeft: 5,
        targetAmount: 2500000,
        currentAmount: 1250000,
        donorCount: 28,
        isFeatured: true,
        createdAt: new Date().toISOString()
      },
      {
        title: "Makanan untuk Koloni Kucing Kampus",
        description: "Mendukung program pemberian makan rutin untuk 25 kucing yang tinggal di area kampus yang sepi selama liburan semester.",
        location: "Bandung",
        image: "https://images.unsplash.com/photo-1574144113084-b6f450cc5e0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=350",
        isUrgent: false,
        daysLeft: 12,
        targetAmount: 1800000,
        currentAmount: 900000,
        donorCount: 15,
        isFeatured: false,
        createdAt: new Date().toISOString()
      },
      {
        title: "SOS: Kucing Jalanan Korban Banjir",
        description: "Bantuan darurat untuk kucing jalanan di kawasan terdampak banjir yang kehilangan sumber makanan dan tempat berteduh.",
        location: "Jakarta",
        image: "https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=350",
        isUrgent: true,
        daysLeft: 3,
        targetAmount: 3000000,
        currentAmount: 1800000,
        donorCount: 42,
        isFeatured: false,
        createdAt: new Date().toISOString()
      },
      {
        title: "Program Makan Kucing Pasar Tradisional",
        description: "Menyediakan makanan berkualitas untuk kucing yang tinggal di 5 pasar tradisional di Surabaya.",
        location: "Surabaya",
        image: "https://images.unsplash.com/photo-1533738363-b7f9aef128ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=350",
        isUrgent: false,
        daysLeft: 18,
        targetAmount: 2200000,
        currentAmount: 880000,
        donorCount: 22,
        isFeatured: false,
        createdAt: new Date().toISOString()
      }
    ];
    
    // Add sample campaigns
    campaigns.forEach(campaign => {
      const id = this.campaignIdCounter++;
      this.campaigns.set(id, { ...campaign, id });
    });
    
    // Sample testimonials
    const testimonials: Omit<Testimonial, 'id'>[] = [
      {
        name: "Dian Sastro",
        role: "Volunteer",
        image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        quote: "Bergabung dengan Catmunitty memberikan saya kesempatan bermakna untuk membantu kucing jalanan. Sangat memuaskan melihat perubahan nyata yang kita buat bersama.",
        createdAt: new Date().toISOString()
      },
      {
        name: "Reza Rahadian",
        role: "Monthly Donor",
        image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        quote: "Saya selalu ingin membantu kucing jalanan tapi tidak tahu caranya. Catmunitty membuat semuanya menjadi mudah dan transparan. Bisa melihat laporan penggunaan donasi adalah hal yang sangat saya hargai.",
        createdAt: new Date().toISOString()
      }
    ];
    
    // Add sample testimonials
    testimonials.forEach(testimonial => {
      const id = this.testimonialIdCounter++;
      this.testimonials.set(id, { ...testimonial, id });
    });
    
    // Sample success stories
    const successStories: Omit<SuccessStory, 'id'>[] = [
      {
        title: "Koloni Kucing Taman Kota Selamat dari Kelaparan",
        description: "Berkat donasi dari 35 donatur, 22 kucing di taman kota kini mendapatkan makanan rutin selama 6 bulan terakhir.",
        image: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=350",
        fullStory: "Cerita lengkap tentang bagaimana koloni kucing di taman kota yang hampir mati kelaparan kini telah dipulihkan berkat bantuan donatur dan relawan.",
        createdAt: new Date().toISOString()
      },
      {
        title: "Menyelamatkan Kucing dari Pembuangan Sampah",
        description: "Program pemberian makan dan edukasi masyarakat menyelamatkan 15 kucing yang hidup di tempat pembuangan sampah.",
        image: "https://images.unsplash.com/photo-1596854407944-bf87f6fdd49e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=350",
        fullStory: "Cerita lengkap tentang proses penyelamatan dan rehabilitasi kucing-kucing yang ditemukan di tempat pembuangan sampah.",
        createdAt: new Date().toISOString()
      }
    ];
    
    // Add sample success stories
    successStories.forEach(story => {
      const id = this.storyIdCounter++;
      this.successStories.set(id, { ...story, id });
    });
    
    // Sample financial report
    const financialReport: Omit<FinancialReport, 'id'> = {
      period: "Januari - Juni 2023",
      totalDonations: 25000000, // Rp 25 juta
      createdAt: new Date().toISOString()
    };
    
    // Add sample financial report
    const reportId = this.reportIdCounter++;
    this.financialReports.set(reportId, { ...financialReport, id: reportId });
    
    // Sample expenses
    const expenses: Omit<Expense, 'id'>[] = [
      {
        reportId,
        category: "Makanan Kucing",
        amount: 15000000, // Rp 15 juta
        percentage: 60,
        createdAt: new Date().toISOString()
      },
      {
        reportId,
        category: "Peralatan Makan",
        amount: 2500000, // Rp 2.5 juta
        percentage: 10,
        createdAt: new Date().toISOString()
      },
      {
        reportId,
        category: "Transportasi Relawan",
        amount: 3750000, // Rp 3.75 juta
        percentage: 15,
        createdAt: new Date().toISOString()
      },
      {
        reportId,
        category: "Edukasi Masyarakat",
        amount: 3750000, // Rp 3.75 juta
        percentage: 15,
        createdAt: new Date().toISOString()
      }
    ];
    
    // Add sample expenses
    expenses.forEach(expense => {
      const id = this.expenseIdCounter++;
      this.expenses.set(id, { ...expense, id });
    });
  }
}

export const storage = new MemStorage();
